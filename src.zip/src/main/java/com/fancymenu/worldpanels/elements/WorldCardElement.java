package com.fancymenu.worldpanels.elements;

import com.fancymenu.worldpanels.data.WorldInfo;
import com.fancymenu.worldpanels.managers.WorldDataManager;
import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.ElementBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Dynamic World Card Element for FancyMenu v3.
 * This element automatically generates cards for all worlds without manual layout.
 * 
 * FancyMenu v3 Compatible - Uses DrawContext directly (no mapping issues).
 */
@Environment(EnvType.CLIENT)
public class WorldCardElement extends AbstractElement {
    private static final Logger LOGGER = LoggerFactory.getLogger(WorldCardElement.class);
    
    private final WorldDataManager worldDataManager;
    private List<WorldInfo> cachedWorlds;
    private long lastUpdate = 0;
    private static final long UPDATE_INTERVAL = 1000; // Update every second
    
    // Card layout settings
    private int cardsPerRow = 3;
    private int cardSpacing = 10;
    private int cardWidth = 200;
    private int cardHeight = 100;
    private boolean showWorldIcons = true;
    private boolean autoLayout = true;
    
    public WorldCardElement(ElementBuilder<?, ?> builder) {
        super(builder);
        try {
            this.worldDataManager = WorldDataManager.getInstance();
        } catch (Exception e) {
            LOGGER.error("Failed to get WorldDataManager instance", e);
            throw new RuntimeException("WorldDataManager not available", e);
        }
        
        // Set reasonable defaults for dynamic layout
        this.baseWidth = 640; // Width for 3 cards + spacing
        this.baseHeight = 400; // Height for multiple rows
        
        // Load initial world data
        updateWorldCache();
    }
    
    /**
     * This is the FancyMenu v3 render method.
     * Based on the error messages, it expects DrawContext directly.
     */
    @Override
    public void method_25394(DrawContext drawContext, int mouseX, int mouseY, float delta) {
        // Update world data periodically
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastUpdate > UPDATE_INTERVAL) {
            updateWorldCache();
            lastUpdate = currentTime;
        }
        
        if (cachedWorlds == null || cachedWorlds.isEmpty()) {
            renderNoWorldsMessage(drawContext, mouseX, mouseY);
            return;
        }
        
        // Dynamically render world cards
        renderWorldCards(drawContext, mouseX, mouseY);
    }
    
    /**
     * Update the cached world data
     */
    private void updateWorldCache() {
        try {
            if (worldDataManager != null && worldDataManager.isInitialized()) {
                cachedWorlds = worldDataManager.getWorlds();
                
                // Auto-adjust layout based on world count
                if (autoLayout && cachedWorlds != null) {
                    adjustLayoutForWorldCount(cachedWorlds.size());
                }
            }
        } catch (Exception e) {
            LOGGER.debug("Failed to update world cache", e);
        }
    }
    
    /**
     * Automatically adjust layout based on number of worlds
     */
    private void adjustLayoutForWorldCount(int worldCount) {
        if (worldCount <= 3) {
            cardsPerRow = worldCount;
            this.baseWidth = (cardWidth * worldCount) + (cardSpacing * (worldCount - 1));
            this.baseHeight = cardHeight;
        } else if (worldCount <= 6) {
            cardsPerRow = 3;
            this.baseWidth = (cardWidth * 3) + (cardSpacing * 2);
            this.baseHeight = (cardHeight * 2) + cardSpacing;
        } else {
            cardsPerRow = 3;
            int rows = (int) Math.ceil((double) worldCount / 3);
            this.baseWidth = (cardWidth * 3) + (cardSpacing * 2);
            this.baseHeight = (cardHeight * rows) + (cardSpacing * (rows - 1));
        }
    }
    
    /**
     * Render world cards dynamically
     */
    private void renderWorldCards(DrawContext drawContext, int mouseX, int mouseY) {
        if (cachedWorlds == null || cachedWorlds.isEmpty()) return;
        
        int startX = getAbsoluteX();
        int startY = getAbsoluteY();
        
        for (int i = 0; i < cachedWorlds.size(); i++) {
            WorldInfo world = cachedWorlds.get(i);
            
            // Calculate card position
            int row = i / cardsPerRow;
            int col = i % cardsPerRow;
            
            int cardX = startX + (col * (cardWidth + cardSpacing));
            int cardY = startY + (row * (cardHeight + cardSpacing));
            
            // Render individual world card
            renderWorldCard(drawContext, world, cardX, cardY, i, mouseX, mouseY);
        }
    }
    
    /**
     * Render a single world card
     */
    private void renderWorldCard(DrawContext drawContext, WorldInfo world, int x, int y, int index, int mouseX, int mouseY) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.textRenderer == null) return;
            
            // Check if mouse is hovering over this card
            boolean isHovered = mouseX >= x && mouseX <= x + cardWidth && 
                               mouseY >= y && mouseY <= y + cardHeight;
            
            // Card background
            int backgroundColor = isHovered ? 0x88444444 : 0x88222222;
            drawContext.fill(x, y, x + cardWidth, y + cardHeight, backgroundColor);
            
            // Card border
            int borderColor = world.isInUse() ? 0xFFFFAA00 : 0xFF666666;
            drawContext.fill(x - 1, y - 1, x + cardWidth + 1, y + cardHeight + 1, borderColor);
            
            // World name
            String worldName = truncateText(world.getWorldName(), 25);
            drawContext.drawText(client.textRenderer, Text.literal(worldName), x + 5, y + 5, 0xFFFFFFFF, false);
            
            // Game mode and difficulty
            String gameInfo = world.getGameModeDisplay();
            if (world.getDifficultyDisplay() != null && !world.getDifficultyDisplay().equals("Unknown")) {
                gameInfo += " - " + world.getDifficultyDisplay();
            }
            drawContext.drawText(client.textRenderer, Text.literal(gameInfo), x + 5, y + 20, 0xFFCCCCCC, false);
            
            // Last played
            String lastPlayed = "Last: " + world.getFormattedLastPlayed();
            drawContext.drawText(client.textRenderer, Text.literal(truncateText(lastPlayed, 30)), x + 5, y + 35, 0xFFAAAAAA, false);
            
            // World size
            String size = "Size: " + world.getFormattedWorldSize();
            drawContext.drawText(client.textRenderer, Text.literal(size), x + 5, y + 50, 0xFFAAAAAA, false);
            
            // Status indicators
            int indicatorY = y + cardHeight - 20;
            if (world.isHardcore()) {
                drawContext.drawText(client.textRenderer, Text.literal("HARDCORE"), x + 5, indicatorY, 0xFFFF0000, false);
            } else if (world.hasCheats()) {
                drawContext.drawText(client.textRenderer, Text.literal("CHEATS"), x + 5, indicatorY, 0xFFFFFF00, false);
            }
            
            // World index indicator
            drawContext.drawText(client.textRenderer, Text.literal("#" + (index + 1)), x + cardWidth - 25, y + 5, 0xFF888888, false);
            
        } catch (Exception e) {
            LOGGER.debug("Failed to render world card for: {}", world.getWorldName(), e);
            // Fallback - just draw a simple rectangle
            drawContext.fill(x, y, x + cardWidth, y + cardHeight, 0x88FF0000);
        }
    }
    
    /**
     * Render message when no worlds are found
     */
    private void renderNoWorldsMessage(DrawContext drawContext, int mouseX, int mouseY) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.textRenderer == null) return;
            
            int centerX = getAbsoluteX() + (getAbsoluteWidth() / 2);
            int centerY = getAbsoluteY() + (getAbsoluteHeight() / 2);
            
            drawContext.drawText(client.textRenderer, Text.literal("No worlds found"), centerX - 50, centerY - 10, 0xFFFFFFFF, false);
            drawContext.drawText(client.textRenderer, Text.literal("Create a world to see it here"), centerX - 80, centerY + 5, 0xFFCCCCCC, false);
        } catch (Exception e) {
            LOGGER.debug("Failed to render no worlds message", e);
        }
    }
    
    /**
     * Truncate text to fit in card
     */
    private String truncateText(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
    
    // Configuration methods for FancyMenu editor
    public void setCardsPerRow(int cardsPerRow) {
        this.cardsPerRow = Math.max(1, Math.min(6, cardsPerRow));
        this.autoLayout = false; // Disable auto layout when manually set
    }
    
    public void setCardSpacing(int spacing) {
        this.cardSpacing = Math.max(0, Math.min(50, spacing));
    }
    
    public void setCardSize(int width, int height) {
        this.cardWidth = Math.max(100, Math.min(400, width));
        this.cardHeight = Math.max(50, Math.min(200, height));
    }
    
    public void setShowWorldIcons(boolean show) {
        this.showWorldIcons = show;
    }
    
    public void setAutoLayout(boolean auto) {
        this.autoLayout = auto;
        if (auto && cachedWorlds != null) {
            adjustLayoutForWorldCount(cachedWorlds.size());
        }
    }
    
    // Getters for editor
    public int getCardsPerRow() { return cardsPerRow; }
    public int getCardSpacing() { return cardSpacing; }
    public int getCardWidth() { return cardWidth; }
    public int getCardHeight() { return cardHeight; }
    public boolean isShowWorldIcons() { return showWorldIcons; }
    public boolean isAutoLayout() { return autoLayout; }
    public int getWorldCount() { return cachedWorlds != null ? cachedWorlds.size() : 0; }
    
    /**
     * Override getDisplayName to return Text (FancyMenu v3 expects this)
     */
    @Override
    public Text getDisplayName() {
        return Text.literal("Dynamic World Cards (" + getWorldCount() + " worlds)");
    }
}