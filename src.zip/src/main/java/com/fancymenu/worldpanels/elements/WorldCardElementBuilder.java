package com.fancymenu.worldpanels.elements;

import de.keksuccino.fancymenu.customization.element.ElementBuilder;
import de.keksuccino.fancymenu.customization.element.SerializedElement;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Builder for Dynamic World Card Elements - FancyMenu v3 Compatible.
 * Handles serialization/deserialization and registration with FancyMenu.
 */
@Environment(EnvType.CLIENT)
public class WorldCardElementBuilder extends ElementBuilder<WorldCardElement, WorldCardEditorElement> {
    private static final Logger LOGGER = LoggerFactory.getLogger(WorldCardElementBuilder.class);
    
    public WorldCardElementBuilder() {
        super("worldcard", "World Cards");
    }
    
    @Override
    public WorldCardElement createElement(SerializedElement serialized) {
        WorldCardElement element = new WorldCardElement(this);
        
        try {
            // Deserialize configuration
            String cardsPerRowStr = serialized.getProperty("cards_per_row");
            if (cardsPerRowStr != null) {
                element.setCardsPerRow(Integer.parseInt(cardsPerRowStr));
            }
            
            String cardSpacingStr = serialized.getProperty("card_spacing");
            if (cardSpacingStr != null) {
                element.setCardSpacing(Integer.parseInt(cardSpacingStr));
            }
            
            String cardWidthStr = serialized.getProperty("card_width");
            String cardHeightStr = serialized.getProperty("card_height");
            if (cardWidthStr != null && cardHeightStr != null) {
                element.setCardSize(Integer.parseInt(cardWidthStr), Integer.parseInt(cardHeightStr));
            }
            
            String showIconsStr = serialized.getProperty("show_icons");
            if (showIconsStr != null) {
                element.setShowWorldIcons(Boolean.parseBoolean(showIconsStr));
            }
            
            String autoLayoutStr = serialized.getProperty("auto_layout");
            if (autoLayoutStr != null) {
                element.setAutoLayout(Boolean.parseBoolean(autoLayoutStr));
            }
            
        } catch (Exception e) {
            LOGGER.warn("Failed to deserialize world card element properties", e);
        }
        
        return element;
    }
    
    @Override
    public WorldCardEditorElement createEditorElement(WorldCardElement element) {
        return new WorldCardEditorElement(element, this);
    }
    
    @Override
    public SerializedElement serializeElement(WorldCardElement element) {
        SerializedElement serialized = new SerializedElement(this.getElementType());
        
        try {
            // Serialize configuration
            serialized.putProperty("cards_per_row", String.valueOf(element.getCardsPerRow()));
            serialized.putProperty("card_spacing", String.valueOf(element.getCardSpacing()));
            serialized.putProperty("card_width", String.valueOf(element.getCardWidth()));
            serialized.putProperty("card_height", String.valueOf(element.getCardHeight()));
            serialized.putProperty("show_icons", String.valueOf(element.isShowWorldIcons()));
            serialized.putProperty("auto_layout", String.valueOf(element.isAutoLayout()));
            
        } catch (Exception e) {
            LOGGER.warn("Failed to serialize world card element properties", e);
        }
        
        return serialized;
    }
    
    /**
     * FancyMenu v3 expects Text return type
     */
    @Override
    public Text getDisplayName(de.keksuccino.fancymenu.customization.element.AbstractElement element) {
        if (element instanceof WorldCardElement) {
            WorldCardElement worldCard = (WorldCardElement) element;
            return Text.literal("World Cards (" + worldCard.getWorldCount() + " worlds)");
        } else {
            return Text.literal("Dynamic World Cards");
        }
    }
    
    /**
     * FancyMenu v3 expects Text[] return type
     */
    @Override
    public Text[] getDescription(de.keksuccino.fancymenu.customization.element.AbstractElement element) {
        return new Text[] {
            Text.literal("Automatically creates cards for all worlds"),
            Text.literal("Dynamically adjusts layout based on world count"),
            Text.literal("Shows world name, gamemode, last played, size"),
            Text.literal("Configurable grid layout and spacing"),
            Text.literal("Live updates when worlds change")
        };
    }
    
    @Override
    public boolean isResizable() {
        return true;
    }
}