package com.fancymenu.worldpanels.elements;

import de.keksuccino.fancymenu.customization.element.editor.AbstractEditorElement;
import de.keksuccino.fancymenu.customization.layout.editor.LayoutEditorScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Editor interface for Dynamic World Card Elements - FancyMenu v3 Compatible.
 * Provides simple interaction methods for configuring world cards.
 */
@Environment(EnvType.CLIENT)
public class WorldCardEditorElement extends AbstractEditorElement {
    private static final Logger LOGGER = LoggerFactory.getLogger(WorldCardEditorElement.class);
    
    private final WorldCardElement worldCardElement;
    private final WorldCardElementBuilder builder;
    
    public WorldCardEditorElement(WorldCardElement element, WorldCardElementBuilder builder) {
        super(element, builder);
        this.worldCardElement = element;
        this.builder = builder;
    }
    
    /**
     * Override tick method to handle periodic updates
     */
    @Override
    public void tick() {
        super.tick();
        // Periodic refresh could be handled here if needed
    }
    
    /**
     * Handle key press events for quick configuration
     * Returns true if the key was handled, false otherwise
     */
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        try {
            // Quick keyboard shortcuts for configuration
            // R key (82) - Refresh worlds
            if (keyCode == 82) {
                refreshWorlds();
                return true;
            }
            
            // L key (76) - Toggle auto layout  
            if (keyCode == 76) {
                worldCardElement.setAutoLayout(!worldCardElement.isAutoLayout());
                markLayoutDirty();
                return true;
            }
            
            // Number keys 1-6 (49-54) - Set cards per row
            if (keyCode >= 49 && keyCode <= 54) {
                int cardsPerRow = keyCode - 48; // Convert key code to number
                worldCardElement.setCardsPerRow(cardsPerRow);
                worldCardElement.setAutoLayout(false); // Disable auto layout when manually set
                markLayoutDirty();
                return true;
            }
            
        } catch (Exception e) {
            LOGGER.debug("Failed to handle key press in world card editor", e);
        }
        
        return false;
    }
    
    /**
     * Handle mouse click events for basic interaction
     * Returns true if the click was handled, false otherwise
     */
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        try {
            // Right click (button 1) - cycle through common configurations
            if (button == 1) {
                cycleConfiguration();
                return true;
            }
            
            // Middle click (button 2) - refresh worlds
            if (button == 2) {
                refreshWorlds();
                return true;
            }
            
        } catch (Exception e) {
            LOGGER.debug("Failed to handle mouse click in world card editor", e);
        }
        
        return false;
    }
    
    /**
     * Cycle through common configurations on right-click
     */
    private void cycleConfiguration() {
        try {
            if (worldCardElement.isAutoLayout()) {
                // Auto -> 2 per row
                worldCardElement.setAutoLayout(false);
                worldCardElement.setCardsPerRow(2);
                LOGGER.info("World Cards: 2 per row");
            } else {
                int currentCards = worldCardElement.getCardsPerRow();
                switch (currentCards) {
                    case 2:
                        // 2 -> 3 per row
                        worldCardElement.setCardsPerRow(3);
                        LOGGER.info("World Cards: 3 per row");
                        break;
                    case 3:
                        // 3 -> 4 per row
                        worldCardElement.setCardsPerRow(4);
                        LOGGER.info("World Cards: 4 per row");
                        break;
                    case 4:
                        // 4 -> 1 per row
                        worldCardElement.setCardsPerRow(1);
                        LOGGER.info("World Cards: 1 per row");
                        break;
                    default:
                        // Any other -> Auto layout
                        worldCardElement.setAutoLayout(true);
                        LOGGER.info("World Cards: Auto Layout");
                        break;
                }
            }
            markLayoutDirty();
        } catch (Exception e) {
            LOGGER.warn("Failed to cycle configuration", e);
        }
    }
    
    /**
     * Refresh world data
     */
    private void refreshWorlds() {
        try {
            com.fancymenu.worldpanels.managers.WorldDataManager.getInstance().refreshWorlds();
            markLayoutDirty();
            LOGGER.info("World data refreshed - found {} worlds", worldCardElement.getWorldCount());
        } catch (Exception e) {
            LOGGER.warn("Failed to refresh worlds", e);
        }
    }
    
    /**
     * Mark layout as dirty to trigger refresh
     */
    private void markLayoutDirty() {
        try {
            LayoutEditorScreen editor = LayoutEditorScreen.getCurrentInstance();
            if (editor != null) {
                // Try to find and call the layout refresh method
                Method[] methods = editor.getClass().getMethods();
                for (Method method : methods) {
                    String methodName = method.getName();
                    if (methodName.equals("markLayoutDirty") || 
                        methodName.equals("markDirty") ||
                        methodName.equals("refresh") ||
                        methodName.equals("refreshLayout")) {
                        method.invoke(editor);
                        return;
                    }
                }
                LOGGER.debug("No suitable refresh method found in LayoutEditorScreen");
            }
        } catch (Exception e) {
            LOGGER.debug("Failed to mark layout dirty", e);
        }
    }
    
    /**
     * Get tooltip text for the editor (FancyMenu v3 compatible)
     */
    public List<Text> getTooltipText() {
        List<Text> tooltip = new ArrayList<>();
        tooltip.add(Text.literal("Dynamic World Cards"));
        tooltip.add(Text.literal("Worlds: " + worldCardElement.getWorldCount()));
        tooltip.add(Text.literal("Layout: " + (worldCardElement.isAutoLayout() ? "Auto" : worldCardElement.getCardsPerRow() + " per row")));
        tooltip.add(Text.literal("Size: " + worldCardElement.getCardWidth() + "x" + worldCardElement.getCardHeight()));
        tooltip.add(Text.literal(""));
        tooltip.add(Text.literal("Controls:"));
        tooltip.add(Text.literal("Right-click: Cycle layout"));
        tooltip.add(Text.literal("Middle-click: Refresh worlds"));
        tooltip.add(Text.literal("R: Refresh worlds"));
        tooltip.add(Text.literal("L: Toggle auto layout"));
        tooltip.add(Text.literal("1-6: Set cards per row"));
        return tooltip;
    }
    
    /**
     * Get status text for display in editor (FancyMenu v3 compatible)
     */
    public Text getStatusText() {
        int worldCount = worldCardElement.getWorldCount();
        String layout = worldCardElement.isAutoLayout() ? "Auto" : worldCardElement.getCardsPerRow() + "/row";
        return Text.literal(String.format("World Cards: %d worlds (%s)", worldCount, layout));
    }
    
    /**
     * Check if this editor element supports a specific action
     */
    public boolean supportsAction(String action) {
        return action.equals("configure") || 
               action.equals("refresh") || 
               action.equals("layout") ||
               action.equals("cycle");
    }
    
    /**
     * Execute an action if supported
     */
    public boolean executeAction(String action) {
        try {
            switch (action.toLowerCase()) {
                case "refresh":
                    refreshWorlds();
                    return true;
                case "cycle":
                case "configure":
                    cycleConfiguration();
                    return true;
                case "layout":
                    worldCardElement.setAutoLayout(!worldCardElement.isAutoLayout());
                    markLayoutDirty();
                    return true;
                default:
                    return false;
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to execute action: {}", action, e);
            return false;
        }
    }
    
    /**
     * Get display name for the editor element (FancyMenu v3 compatible)
     */
    @Override
    public Text getDisplayName() {
        return Text.literal("World Cards Editor (" + worldCardElement.getWorldCount() + " worlds)");
    }
}